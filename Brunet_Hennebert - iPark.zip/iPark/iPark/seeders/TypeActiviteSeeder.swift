//
//  TypeActiviteSeeder.swift
//  iPark
//
//  Created by Jade HENNEBERT on 28/03/2018.
//  Copyright © 2018 Jade HENNEBERT. All rights reserved.
//

import Foundation

struct TypeActiviteSeeder {
    let typeActivites: [String] = [
        "Marche à pied","Velo"]
}
